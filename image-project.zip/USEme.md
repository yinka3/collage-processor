# How To Use Our Graphic User Interface

    * Update(04/12/23)
        - The load PPM Image or Project has been changed to just load Imaged or Project as we have
            allowed for the ability to read in more image types which are png and jpg file types.
        -In addtion, the save image now also has the ability to save files as a png and jpg files.
        - No additional featues were added to the GUI in order for this new system support.

    * When the GUI first pops up, a quick direction for where things are
        - The left has the layer processing how many layers are in the project and what filters
          are being applied to certain layers. The right side has all the filters to apply onto
          the layer. The top has the processing for adding something new, the bottom is for saving
          in two different ways. The center has
    
    * As for starting the project, there is a create Project up top, when the button is clicked,
        two pop ups will appear at a time, one to enter the width of the project and one to enter
        the height of the project.

    * Now to add a layer to the project, right next to the create Project button, there is a add
        layer button that when clicked, another pop ups will appear that will first show you a
        demanding monkey asking to give you the layer name, then another pop up will appear to input
        the layer name.

    * Now, you can continously add layers, there are no limits. However, to now add an image to your
        layer, there is a text field that askes for the layer in the current project then you click
        layer to load image or project. This will pop up the file explorer on the local machine
        being used. Then after picking an image and comfirming, two pop ups will happen, one with
        asking for an offset position of height and the other of the width.
        * MUST HAVE SOMETHING IN FOR TEXT FIELD TO USE THE BUTTON
    
    * After, an image is on a layer, on the right side, there are radio buttons that have all the 
        available filters you can use on a layer. To get the filter applied, there is a text field 
        on the top right, where you input any layer that is on the project and then click any of the
        buttons. * MUST HAVE SOMETHING IN FOR TEXT FIELD TO USE THE BUTTON

    * Finally, after using the filtering and needing to save the image, on the button area, there 
        are two buttons, the one on the left is for saving a ppm image while the other is for
        saving a collage. When either buttons are clicked, a pop up of the file explorer will show
        and then enter the name you want for your new ppm image or collage.

### Commands of the GUI/Text version
    - AddImageToLayer adds an image to a layer.
    - AddLayer adds a layer to a collage.
    - CreateProject creates a new collage.
    - Load loads an image on to the processor.
    - Save collage saves the college as a active project so it can continue to be worked on.
    - SaveImage saves the collage as an image that cannot be edited.
    - Filter applies a filter to a layer.
    - Set Blend applies a filter to certain layers