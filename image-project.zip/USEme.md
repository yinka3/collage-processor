# How To Use Our Graphic User Interface

    * When the GUI first pops up, a quick direction for where things are
        - The left has the layer processing how many layers are in the project and what filters
          are being applied to certain layers. The right side has all the filters to apply onto
          the layer. The top has the processing for adding something new, the bottom is for saving
          in two different ways. The center has
    
    * As for starting the project, there is a create Project up top, when the button is clicked,
        two pop ups will appear at a time, one to enter the width of the project and one to enter
        the height of the project.

    * Now to add a layer to the project, right next to the create Project button, there is a add
        layer button that when clicked, another pop ups will appear that will first show you a
        demanding monkey asking to give you the layer name, then another pop up will appear to input
        the layer name.

    * Now, you can continously add layers, there are no limits. However, to now add an image to your
        layer, there is a text field that askes for the layer in the current project then you click
        layer to load image or project. This will pop up the file explorer on the local machine
        being used. Then after picking an image and comfirming, two pop ups will happen, one with
        asking for an offset position of height and the other of the width.
        * MUST HAVE SOMETHING IN FOR TEXT FIELD TO USE THE BUTTON
    
    * After, an image is on a layer, on the right side, there are radio buttons that have all the 
        available filters you can use on a layer. To get the filter applied, there is a text field 
        on the top right, where you input any layer that is on the project and then click any of the
        buttons. * MUST HAVE SOMETHING IN FOR TEXT FIELD TO USE THE BUTTON

    * Finally, after using the filtering and needing to save the image, on the button area, there 
        are two buttons, the one on the left is for saving a ppm image while the other is for
        saving a collage. When either buttons are clicked, a pop up of the file explorer will show
        and then enter the name you want for your new ppm image or collage.
    