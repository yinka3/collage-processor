package cs3500.imageutil;

public interface IHSL {
  double getSaturation();
  double getHue();
  double getLight();
}
